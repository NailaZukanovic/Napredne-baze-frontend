export function formatPrice(price){
    return price.toLocaleString('en-US', {
        style: 'currency',
        currency: 'USD'
    })
}

export const foodItems = [

    {
        name: 'Cheese Pizza',
        img: '/img/pizza.png',
        section: 'Pizzas',
        price: 1
    },
    {
        name: 'Pepperoni Pizza',
        img: '/img/pizza2.jpeg',
        section: 'Pizzas',
        price: 1.5
    },
    {
        name: 'Chicken Pizza',
        img: '/img/chicken-pizza.jpeg',
        section: 'Pizzas',
        price: 2
    },
    {
        name: 'Veggie Pizza',
        img: '/img/healthy-pizza.jpeg',
        section: 'Pizzas',
        price: 2

    },
];

export const Automobili = [
    {
        sifra: '123465789', 
        registracija : '123456798', 
        godina_proizvodnje : '123456789',
        model_vozila: '132465789'

    },
    {
        sifra: '123465789', 
        registracija : '123456798', 
        godina_proizvodnje : '123456789',
        model_vozila: '132465789'

    },
    {
        sifra: '123465789', 
        registracija : '123456798', 
        godina_proizvodnje : '123456789',
        model_vozila: '132465789'

    },
]
export const foods = foodItems.reduce((res, food) => {
    if(!res[food.section]){
        res[food.section] = [];
    }
    res[food.section].push(food)
    return res;
}, {})
