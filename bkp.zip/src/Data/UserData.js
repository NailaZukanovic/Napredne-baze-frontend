
// UserToken je zamena za header gde se skladisti bearer token
export let UserToken = null;

export let UsersData = [
    {
        username: "Almir",
        password: "kvax",
        roleId: 1,
        firstName: "Almir",
        lastName: "Kvakic",
        dateOfBirth: "2022-05-19T14:21:23.923Z",
        jmbg: "342432342",
        phoneNumbers: "064555555",
        emails: "almir@gmail.com",
        address: "Povise Parka 1",
        orders: []
    }
];



