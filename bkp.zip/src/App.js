import React, { useState } from "react";
import { GlobalStyle } from "./Styles/GobalStyle";
import { Navbar } from "./Navbar/Navbar";
import { Banner } from "./Banner/Banner";
import { Menu } from "./Menu/Menu";
import { FoodDialog } from "./FoodDialog/FoodDialog";
import { Order } from "./Order/Order";
import { useOpenFood } from "./Hooks/useOpenFood";
import { useOrders } from "./Hooks/useOrders";
import { useTitle } from "./Hooks/useTitle";
import { UserAuth } from "./User/UserAuth";
import { UserToken } from "./Data/UserData"
import { UserProfile } from "./User/UserProfile";

function App() {
  const openFood = useOpenFood();
  const orders = useOrders();
  useTitle({ ...openFood, ...orders });

  return (
    <>      
      <GlobalStyle />
      <FoodDialog {...openFood} {...orders} />
      <Navbar />
      {UserToken ? <UserProfile /> : <UserAuth /> }

      <Order {...orders} {...openFood} />
      <Banner />
      <Menu {...openFood} />
    </>
  );
}

export default App;
