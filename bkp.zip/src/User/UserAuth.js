import React, { useState } from "react";
import styled from "styled-components";
import { pizzaRed } from "../Styles/colors";
import { Title } from "../Styles/title";
import { Navbar } from "../Navbar/Navbar";
import { UserToken, UsersData } from "../Data/UserData";




export function UserAuth () {

    let errorMessage = null;
    
    const [isRegister, setIsRegister] = useState(true);
    const [registerInputs, setRegisterInputs] = useState({
        username: "",
        password: "",
        firstName: "",
        lastName: "",
        dateOfBirth: "",
        jmbg: "",
        phoneNumbers: "",
        email: "",
        address: ""
    })

    const [loginInputs, setLoginInputs] = useState({
        email: '',
        password: ''
    })

    const handleRegisterInputChange = (e) => {
        const value = e.target.value;
        setRegisterInputs({
            ...registerInputs,
            [e.target.name]: value
        })
        console.log("reginpouts: ", registerInputs)
    }

    const handleLoginInputChange = (e) => {
        const value = e.target.value;
        setLoginInputs({
            ...loginInputs,
            [e.target.name]: value
        })
        console.log("loginputs: ", loginInputs)
    }


    const login = () => {
        // post method saljes apiju vracas status

        // privremeno
        let foundUser = UsersData.find(({emails}) => emails == loginInputs.email);

        if (foundUser) {
            if (foundUser.password) { 
                UserToken = foundUser.username;
            } else { 
                errorMessage = 'Korisnicka sifra nije tacna'
                console.log(errorMessage)
            }
        } else { 
            errorMessage = 'Korisnik nije pronadjen';
            console.log(errorMessage)
        }
    } // gledaj

    const register = () => {
        // post methoda registracije

        if (
            registerInputs.username &&
            registerInputs.emails &&
            registerInputs.password &&
            registerInputs.phoneNumbers
        ) {
            UsersData.push(registerInputs);
        } else {
            errorMessage = "Potrebno je uneti sva polja"
        }
        
    }

    const Login = () => {
        return (
            <div>
                <input name="email" type="text" value={ loginInputs.email } onChange={handleLoginInputChange}/>
                <br></br>
                <input name="password" type="password" value={ loginInputs.password } onChange={handleLoginInputChange}/>
                <br></br>
                <button onClick={() => login()} > Prijavi se </button>
            </div>
        );
    }

    const Register = () => {
        return (
            <div>
                <input name="email" type="text" value={ registerInputs.email } onChange={handleRegisterInputChange} />
                <br></br>
                <input name="password" type="password" value={ registerInputs.password } onChange={handleRegisterInputChange} />
                <br></br>
                <button onClick={() => register()} > Registruj se </button>
            </div> 
        );
    }

    return (
        <>
            {isRegister ? <Register /> : <Login />}
            <button 
                onClick={() => {
                    setIsRegister(true)
                }}
            >Registracija</button>
            <button 
                onClick={() => {
                    setIsRegister(false)
                }}
            >Login</button>
        </>
    );
}