import styled from 'styled-components';

export const Title = styled.div`
  font-family: 'Righteous', cursive; 
`
